package com.myJMS.messagingjms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagingJmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessagingJmsApplication.class, args);
	}

}
